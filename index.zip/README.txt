CALL RECORDER - iPhone prototype

This is a web app prototype and recording library, not a FaceTime capture tool.
iOS does not allow a normal web app to capture FaceTime audio/video or continue
capturing it in the background. The Record Call button starts a session timer
and explains how to use iPhone's built-in Screen Recording. Stop Session lets
you import the video after iOS saves it. Imported videos are stored in this
browser's local IndexedDB library.

To use on iPhone:
1. Put these files on a static HTTPS website (or open index.html locally for a quick test).
2. In Safari, open the site and use Share > Add to Home Screen.
3. For a call, start iPhone Screen Recording from Control Center.
4. After stopping the iPhone screen recording, return to this app, tap Stop Session & Add Video, and select the saved video.
5. Use Save and the iOS share/download flow to move a copy to Files.

Record calls only when everyone involved knows and agrees.
